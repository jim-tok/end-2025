/**
 * KOTO BATUAH ECOSYSTEM v19.9.0 - GITHUB BRIDGE PROTOCOL
 * Fix: Forced Asset Connection & Header Authentication
 */

const CONFIG = {
  CSV_PUB_URL: "https://docs.google.com/spreadsheets/d/e/2PACX-1vST8FRhHwsV9E96CIpQGGXqU86cbbTdTLX03yNzBBeu5pPnOpMtKGb7XccGc9V0ZcB5ALHaP4t9Yy40/pub?output=csv",
  // Path absolut ke Raw GitHub
  GITHUB_BASE: "https://raw.githubusercontent.com/jimtok/jimtok/main/ekosistem-koto-batuah/assets/ogie/",
  DEFAULT_CONFIG_DOMAIN: "kotobatuah.web.id"
};

export default {
  async fetch(request) {
    const url = new URL(request.url);
    const domain = url.hostname.toLowerCase().replace('www.', '');
    const path = url.pathname === "/" ? "home" : url.pathname.replace(/^\/|\/$/g, "");

    try {
      // Fetch CSV dengan header agar fresh
      const res = await fetch(CONFIG.CSV_PUB_URL, { 
        headers: { 'User-Agent': 'KotoBatuah-Engine' },
        cf: { cacheTtl: 0 } 
      });
      const csv = await res.text();
      const allData = parseCSV(csv);
      const siteData = allData.filter(d => d.domain === domain);
      const page = siteData.find(d => d.slug === path);

      if (page) {
        let bodyHtml = (page.html && !page.html.includes('<')) ? decodeBase64(page.html) : (page.html || "");
        
        // Memastikan semua {{IMG}} mengarah ke GitHub Raw secara absolut
        bodyHtml = bodyHtml.replaceAll('{{IMG}}', CONFIG.GITHUB_BASE);
        
        // Logo path
        const logoUrl = `${CONFIG.GITHUB_BASE}logo.png`;

        return new Response(renderLuxury(page, domain, bodyHtml, logoUrl), {
          headers: { 
            'Content-Type': 'text/html; charset=utf-8',
            'Cache-Control': 'no-cache'
          }
        });
      }
      return Response.redirect(url.origin + '/', 302);
    } catch (e) { return new Response("Reconnecting to Assets..."); }
  }
};

function renderLuxury(p, d, content, logo) {
  const brandName = p.brand || "Ogie Home Solution";
  return `<!DOCTYPE html><html lang="id" class="scroll-smooth"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>${p.title}</title><script src="https://cdn.tailwindcss.com"></script><link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;700;800&display=swap" rel="stylesheet"><style>body{font-family:'Plus Jakarta Sans',sans-serif;}</style></head>
<body class="bg-white text-slate-900">
    <nav class="fixed top-0 w-full bg-white/90 backdrop-blur-lg z-[100] border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-6 h-20 flex justify-between items-center">
            <a href="/" class="flex items-center">
                <img src="${logo}" onerror="this.onerror=null; this.src='https://ui-avatars.com/api/?name=OGIE+HOME&background=0D9488&color=fff&size=200';" class="h-10 w-auto object-contain">
            </a>
            <div class="hidden md:flex items-center gap-8 font-bold text-[11px] uppercase tracking-[0.2em] text-slate-500">
                <a href="#layanan" class="hover:text-emerald-600 transition">Layanan</a>
                <a href="#proyek" class="hover:text-emerald-600 transition">Proyek</a>
                <a href="https://wa.me/6285234220844" class="bg-slate-900 text-white px-6 py-3 rounded-xl hover:bg-emerald-600 transition">WhatsApp</a>
            </div>
            <button onclick="document.getElementById('mobile-menu').classList.toggle('hidden')" class="md:hidden p-2">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-slate-900" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7" /></svg>
            </button>
        </div>
        <div id="mobile-menu" class="hidden flex-col bg-white border-b p-6 space-y-4 font-bold text-sm uppercase tracking-widest md:hidden shadow-xl">
            <a href="#layanan" onclick="this.parentElement.classList.add('hidden')">Layanan</a>
            <a href="#proyek" onclick="this.parentElement.classList.add('hidden')">Proyek</a>
            <a href="https://wa.me/6285234220844" class="text-emerald-600">Konsultasi WA</a>
        </div>
    </nav>
    <main class="pt-20">${content}</main>
    <footer class="py-20 text-center bg-slate-50">
        <p class="font-black text-xl italic mb-4">${brandName}</p>
        <p class="text-[10px] text-slate-400 font-bold uppercase tracking-[0.5em]">&copy; 2026 KOTO BATUAH EKOSISTEM</p>
    </footer>
</body></html>`;
}

function decodeBase64(d){try{let b=atob(d.trim()),y=new Uint8Array(b.length);for(let i=0;i<b.length;i++)y[i]=b.charCodeAt(i);return new TextDecoder().decode(y)}catch(e){return d}}
function parseCSV(t){let r=[],o=[],c="",q=!1;for(let i=0;i<t.length;i++){let x=t[i],n=t[i+1];if(q&&x==='"'&&n==='"' ){c+='"';i++}else if(x==='"')q=!q;else if(x===","&&!q){o.push(c);c=""}else if((x==="\n"|x==="\r")&&!q){if(c!==""||o.length>0){o.push(c);r.push(o);o=[];c=""}}else c+=x}if(c!==""||o.length>0){o.push(c);r.push(o)}let h=r[0].map(s=>s.trim().toLowerCase());return r.slice(1).map(l=>{let a={};h.forEach((s,j)=>a[s]=l[j]||"");return a})}
