/**
 * KOTO BATUAH ECOSYSTEM v19.1.0 - HUB-SPOKES ENGINE
 * Hub Central: kotobatuah.web.id (Wadah Kolaborasi UMKM & AI)
 * Technology Partner: James (Jim Koto)
 * Principle: "Time is Precious Currency"
 */

const CONFIG = {
  CSV_PUB_URL: "https://docs.google.com/spreadsheets/d/e/2PACX-1vST8FRhHwsV9E96CIpQGGXqU86cbbTdTLX03yNzBBeu5pPnOpMtKGb7XccGc9V0ZcB5ALHaP4t9Yy40/pub?output=csv",
  DEFAULT_CONFIG_DOMAIN: "kotobatuah.web.id", // REVISI: Central Hub Koto Batuah
  GA_GLOBAL: "G-FE4HB21ZPY"
};

export default {
  async fetch(request) {
    const url = new URL(request.url);
    const domain = url.hostname.toLowerCase().replace('www.', '');
    const path = url.pathname === "/" ? "home" : url.pathname.replace(/^\/|\/$/g, "");

    try {
      const res = await fetch(CONFIG.CSV_PUB_URL, { cf: { cacheTtl: 1 } });
      const csv = await res.text();
      const allData = parseCSV(csv);
      
      const siteData = allData.filter(d => d.domain.trim().toLowerCase() === domain);
      
      // Jika domain prospek belum terdaftar, otomatis arahkan ke visi Koto Batuah Hub
      if (siteData.length === 0 && domain !== CONFIG.DEFAULT_CONFIG_DOMAIN) {
        return new Response("Aset Digital Koto Batuah - Sedang dalam proses akselerasi AI.", { status: 404 });
      }

      const getConfig = (slug) => {
        // Mencari config di domain aktif, jika tidak ada ambil dari kotobatuah.web.id (Hub)
        return allData.find(d => d.domain === domain && d.slug === slug) || 
               allData.find(d => d.domain === CONFIG.DEFAULT_CONFIG_DOMAIN && d.slug === slug);
      };

      // 1. ADS.TXT (Inherit from Hub if not set)
      if (path === "ads.txt") {
        const adsRecord = getConfig("_config_adsense");
        return new Response(adsRecord ? (adsRecord.content || adsRecord.html) : "", { headers: { 'Content-Type': 'text/plain' } });
      }

      // 2. SITEMAP
      if (path === "sitemap.xml") {
        return new Response(generateSitemap(siteData, url.origin), { headers: { 'Content-Type': 'application/xml' } });
      }

      // 3. PAGE ROUTING & RENDERING
      const page = siteData.find(d => d.slug === path);
      if (page) {
        const globalConfig = getConfig("_config_global");
        
        let htmlContent = "";
        if (page.html && page.html.trim().length > 10) {
            // Deteksi otomatis: Plain HTML atau Base64
            if (page.html.trim().startsWith('<')) {
                htmlContent = page.html;
            } else {
                htmlContent = decodeBase64(page.html);
            }
        } else {
            // Render UI Modern untuk UMKM/Klien jika kolom HTML kosong
            htmlContent = renderHubSpokeFallback(page, domain);
        }
        
        // Injeksi Global Scripts/Adsense dari Hub
        if (globalConfig && globalConfig.html && globalConfig.html !== "-") {
           htmlContent = htmlContent.replace('</head>', `${globalConfig.html}</head>`);
        }
        
        // Selalu pastikan G-Analytics Global tertanam
        if (!htmlContent.includes(CONFIG.GA_GLOBAL)) {
            const gaScript = `<script async src="https://www.googletagmanager.com/gtag/js?id=${CONFIG.GA_GLOBAL}"></script><script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${CONFIG.GA_GLOBAL}');</script>`;
            htmlContent = htmlContent.replace('</head>', `${gaScript}</head>`);
        }
        
        return new Response(htmlContent, { headers: { 'Content-Type': 'text/html; charset=utf-8' } });
      }

      return Response.redirect(url.origin + '/', 302);
    } catch (e) {
      return new Response("Koto Batuah Ecosystem: Sedang Sinkronisasi...");
    }
  }
};

function renderHubSpokeFallback(p, d) {
  const accentColor = p.theme_color || '#d97706';
  return `<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>${p.title}</title><script src="https://cdn.tailwindcss.com"></script><link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;700;800&display=swap" rel="stylesheet"><style>body{font-family:'Plus Jakarta Sans',sans-serif;}</style></head><body class="bg-white text-slate-900"><nav class="p-6 max-w-7xl mx-auto flex justify-between items-center"><span class="font-extrabold text-2xl tracking-tighter uppercase">${d}</span><div class="h-2 w-2 rounded-full bg-green-500 animate-pulse"></div></nav><main class="min-h-[70vh] flex flex-col justify-center items-center p-6 text-center"><h1 class="text-5xl md:text-7xl font-extrabold mb-6 tracking-tight">${p.hero_headline || p.title}</h1><p class="text-lg text-slate-500 max-w-2xl mb-10 leading-relaxed">${p.hero_sub || p.description || 'Wadah kolaborasi UMKM & Digital Enthusiast Koto Batuah.'}</p><div class="flex gap-4"><a href="https://wa.me/6287763030330" class="bg-slate-900 text-white px-10 py-4 rounded-2xl font-bold transition-transform hover:scale-105">${p.cta_text || 'Kolaborasi Sekarang'}</a></div></main><footer class="p-12 text-center"><p class="text-xs font-bold text-slate-400 tracking-widest uppercase mb-4">Powered by Koto Batuah Hub (kotobatuah.web.id)</p><div class="flex justify-center gap-4 opacity-30 grayscale"><img src="https://akomodanetwork.com/favicon.ico" class="h-4"></div></footer></body></html>`;
}

function generateSitemap(data, origin) {
  const urls = data.filter(d => !d.slug.startsWith('_')).map(d => `<url><loc>${origin}/${d.slug === 'home' ? '' : d.slug}</loc></url>`).join('');
  return `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls}</urlset>`;
}

function decodeBase64(d){try{let b=atob(d.trim()),y=new Uint8Array(b.length);for(let i=0;i<b.length;i++)y[i]=b.charCodeAt(i);return new TextDecoder().decode(y)}catch(e){return d}}
function parseCSV(t){let r=[],o=[],c="",q=!1;for(let i=0;i<t.length;i++){let x=t[i],n=t[i+1];if(q&&x==='"'&&n==='"' ){c+='"';i++}else if(x==='"')q=!q;else if(x===","&&!q){o.push(c);c=""}else if((x==="\n"||x==="\r")&&!q){if(c!==""||o.length>0){o.push(c);r.push(o);o=[];c=""}}else c+=x}if(c!==""||o.length>0){o.push(c);r.push(o)}let h=r[0].map(s=>s.trim().toLowerCase());return r.slice(1).map(l=>{let a={};h.forEach((s,j)=>a[s]=l[j]||"");return a})}
