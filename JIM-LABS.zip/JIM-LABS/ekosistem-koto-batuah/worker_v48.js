/**
 * KOTO BATUAH ECOSYSTEM v48.0.0 - THE FINAL STABILITY
 * Fokus: Memperbaiki pembacaan data yang pecah tanpa merubah struktur Sheet.
 */

const CONFIG = {
  CSV_PUB_URL: "https://docs.google.com/spreadsheets/d/e/2PACX-1vST8FRhHwsV9E96CIpQGGXqU86cbbTdTLX03yNzBBeu5pPnOpMtKGb7XccGc9V0ZcB5ALHaP4t9Yy40/pub?output=csv",
  GITHUB_ROOT: "https://raw.githubusercontent.com/jimtok/jimtok/main/ekosistem-koto-batuah/assets/",
  GA_ID: "G-FE4HB21ZPY"
};

export default {
  async fetch(request) {
    const url = new URL(request.url);
    const domain = url.hostname.toLowerCase().replace('www.', '').trim();
    const path = (url.pathname.toLowerCase().replace(/^\/|\/$/g, "")) || "home";

    try {
      const response = await fetch(`${CONFIG.CSV_PUB_URL}&nocache=${Date.now()}`);
      const csvText = await response.text();
      
      // Menggunakan pembaca CSV yang lebih cerdas terhadap tanda kutip dan koma
      const rows = smartParseCSV(csvText);

      // PENCARIAN SUPER LONGGAR (Agar tidak sensitif spasi/huruf)
      let page = rows.find(r => {
        const d = (r.domain || "").toLowerCase().trim();
        const s = (r.slug || "").toLowerCase().trim();
        const t = (r.type || "").toLowerCase().trim();
        
        // Utamakan slug yang pas, atau jika ini homepage ambil yang type config/home
        return d.includes(domain) && (path === s || (path === "home" && (s === "home" || t === "config")));
      });

      // Fallback terakhir: Ambil baris pertama yang domainnya cocok
      if (!page) {
        page = rows.find(r => (r.domain || "").toLowerCase().includes(domain));
      }

      if (page) {
        const folder = (page.folder || domain.split('.')[0]).trim();
        const baseAssetUrl = `${CONFIG.GITHUB_ROOT}${folder}/`;
        
        let bodyHtml = page.html || page.content || "";
        if (bodyHtml && !bodyHtml.includes('<') && bodyHtml.length > 10) {
          bodyHtml = decodeB64(bodyHtml);
        }
        
        bodyHtml = bodyHtml.split('{{IMG}}').join(baseAssetUrl);

        const brandName = (page.brand || "").trim();
        const isBranded = brandName.length > 0;

        return new Response(isBranded ? renderLuxury(page, bodyHtml, `${baseAssetUrl}logo.png`, brandName) : renderRaw(page, bodyHtml), {
          headers: { 'Content-Type': 'text/html; charset=utf-8' }
        });
      }

      return new Response(`Error: Data untuk [${domain}] tidak terbaca. Periksa kolom domain di Sheet.`, { status: 404 });

    } catch (e) {
      return new Response("System Crash: " + e.message, { status: 500 });
    }
  }
};

function renderRaw(p, content) {
  return `<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>${p.title || 'Koto Batuah'}</title><script src="https://cdn.tailwindcss.com"></script></head><body>${content}</body></html>`;
}

function renderLuxury(p, content, logo, brand) {
  return renderRaw(p, `
    <nav style="position:fixed;top:0;width:100%;background:white;height:70px;display:flex;align-items:center;justify-content:space-between;padding:0 20px;border-bottom:1px solid #eee;z-index:9999;">
      <div style="display:flex;align-items:center;gap:10px;">
        <img src="${logo}" onerror="this.src='https://ui-avatars.com/api/?name=${encodeURIComponent(brand)}';" style="height:35px;">
        <span style="font-weight:bold;">${brand}</span>
      </div>
      <a href="https://wa.me/${p.cta_link || '6287763030330'}" style="background:#000;color:#fff;padding:8px 16px;border-radius:8px;text-decoration:none;font-size:12px;font-weight:bold;">CONNECT</a>
    </nav><div style="padding-top:70px;">${content}</div>`);
}

function smartParseCSV(text) {
  const lines = text.split(/\r?\n/);
  const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
  return lines.slice(1).map(line => {
    // Regex ini menangani koma di dalam tanda kutip (sering terjadi di kolom HTML)
    const values = line.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
    let obj = {};
    headers.forEach((h, i) => {
      obj[h] = (values[i] || "").replace(/^"|"$/g, "").trim();
    });
    return obj;
  });
}

function decodeB64(d){try{return new TextDecoder().decode(Uint8Array.from(atob(d.trim()),c=>c.charCodeAt(0)))}catch(e){return d}}