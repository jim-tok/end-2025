/**
 * KOTO BATUAH ECOSYSTEM v48.0.1 - REPAIR STABILITY
 * Fokus: Memperbaiki pembacaan data yang pecah/blank akibat format CSV Google Sheet.
 */

const CONFIG = {
  CSV_PUB_URL: "https://docs.google.com/spreadsheets/d/e/2PACX-1vST8FRhHwsV9E96CIpQGGXqU86cbbTdTLX03yNzBBeu5pPnOpMtKGb7XccGc9V0ZcB5ALHaP4t9Yy40/pub?output=csv",
  GITHUB_ROOT: "https://raw.githubusercontent.com/jimtok/jimtok/main/ekosistem-koto-batuah/assets/",
  GA_ID: "G-FE4HB21ZPY"
};

export default {
  async fetch(request) {
    const url = new URL(request.url);
    const domain = url.hostname.toLowerCase().replace('www.', '').trim();
    const path = (url.pathname.toLowerCase().replace(/^\/|\/$/g, "")) || "home";

    try {
      const response = await fetch(`${CONFIG.CSV_PUB_URL}&nocache=${Date.now()}`);
      const csvText = await response.text();
      
      // Parser yang lebih stabil untuk data HTML dan koma dalam sel
      const rows = smartParseCSV(csvText);

      // Pencarian data berdasarkan domain dan slug/path
      let page = rows.find(r => {
        const d = (r.domain || "").toLowerCase().trim();
        const s = (r.slug || "").toLowerCase().trim();
        const t = (r.type || "").toLowerCase().trim();
        return d.includes(domain) && (path === s || (path === "home" && (s === "home" || t === "config")));
      });

      // Fallback: Ambil baris pertama yang domainnya cocok jika path tidak ditemukan
      if (!page) {
        page = rows.find(r => (r.domain || "").toLowerCase().includes(domain));
      }

      if (page) {
        const folder = (page.folder || domain.split('.')[0]).trim();
        const baseAssetUrl = `${CONFIG.GITHUB_ROOT}${folder}/`;
        
        // Penambahan fallback header 'body' atau 'konten' untuk mencegah tampilan kosong
        let bodyHtml = page.html || page.content || page.body || page.konten || "";
        
        // Deteksi Base64 yang lebih aman
        if (bodyHtml && !bodyHtml.includes('<') && bodyHtml.length > 20) {
          bodyHtml = decodeB64(bodyHtml);
        }
        
        bodyHtml = bodyHtml.split('{{IMG}}').join(baseAssetUrl);

        const brandName = (page.brand || "").trim();
        const isBranded = brandName.length > 0;

        return new Response(isBranded ? renderLuxury(page, bodyHtml, `${baseAssetUrl}logo.png`, brandName) : renderRaw(page, bodyHtml), {
          headers: { 'Content-Type': 'text/html; charset=utf-8' }
        });
      }

      return new Response(`Error: Data untuk [${domain}] tidak ditemukan di Database Sheet.`, { status: 404 });

    } catch (e) {
      return new Response("System Crash: " + e.message, { status: 500 });
    }
  }
};

function renderRaw(p, content) {
  return `<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>${p.title || 'Koto Batuah'}</title><script src="https://cdn.tailwindcss.com"></script></head><body>${content}</body></html>`;
}

function renderLuxury(p, content, logo, brand) {
  return renderRaw(p, `
    <nav style="position:fixed;top:0;width:100%;background:white;height:70px;display:flex;align-items:center;justify-content:space-between;padding:0 20px;border-bottom:1px solid #eee;z-index:9999;">
      <div style="display:flex;align-items:center;gap:10px;">
        <img src="${logo}" onerror="this.src='https://ui-avatars.com/api/?name=${encodeURIComponent(brand)}';" style="height:35px;">
        <span style="font-weight:bold;font-family:sans-serif;">${brand}</span>
      </div>
      <a href="https://wa.me/${p.cta_link || '6287763030330'}" style="background:#000;color:#fff;padding:8px 16px;border-radius:8px;text-decoration:none;font-size:12px;font-weight:bold;font-family:sans-serif;">CONNECT</a>
    </nav><div style="padding-top:70px;">${content}</div>`);
}

function smartParseCSV(text) {
  if (!text) return [];
  const lines = text.split(/\r?\n/).filter(line => line.trim() !== "");
  const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
  
  return lines.slice(1).map(line => {
    const values = [];
    let curr = '', inQuotes = false;
    // Karakter-by-karakter untuk memastikan koma di dalam HTML tidak memecah kolom
    for (let i = 0; i < line.length; i++) {
        let char = line[i];
        if (char === '"' && line[i+1] === '"') { // Handle double quotes
            curr += '"'; i++;
        } else if (char === '"') {
            inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
            values.push(curr);
            curr = '';
        } else {
            curr += char;
        }
    }
    values.push(curr);

    let obj = {};
    headers.forEach((h, i) => {
      obj[h] = (values[i] || "").trim();
    });
    return obj;
  });
}

function decodeB64(d){try{return new TextDecoder().decode(Uint8Array.from(atob(d.trim()),c=>c.charCodeAt(0)))}catch(e){return d}}